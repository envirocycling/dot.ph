<br /><br />
<div id="footer"><span style="float:left;
	font-weight:bold;"><p>&nbsp;&nbsp;Copyright &#169; 2016 Envirocycling Fiber Inc. (EFI)</p></span><span style="float:right;font-weight:bold;"><p>All Rights Reserved. Powered by EFI-IT Dept.&nbsp;&nbsp;</p></span></div>